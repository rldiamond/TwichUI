# Addon Update Notifications

## [1.0.26](https://github.com/WowUp/WowUp.Addon/tree/1.0.26) (2025-08-07)
[Full Changelog](https://github.com/WowUp/WowUp.Addon/compare/1.0.25...1.0.26) [Previous Releases](https://github.com/WowUp/WowUp.Addon/releases)

- Update TOC version to 11.2.0  
- Keep compat with non-retail releases  