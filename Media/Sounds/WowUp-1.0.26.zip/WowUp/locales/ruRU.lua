-- ruRU localization
local L = LibStub("AceLocale-3.0"):NewLocale("WOWUP", "ruRU")
if not L then return end

L["Notification"] = "Уведомление"
L["You have %d addon to be updated"] = "Вам нужно обновить %d"
L["You have %d addons to be updated"] = "У вас есть %d модификаций для обновления"
L["All addons are up-to-date"] = "Все модификации обновлены"
L["Show a popup with a notification after loading when updates are available"] = "Показывать всплывающее окно с уведомлением после загрузки, когда доступны обновления"
L["Show a chat message indicating whether or not updates are available"] = "Показать сообщение чата, указывающее, доступны ли обновления"
L["Click to open settings"] = true
L["Show a list of all addons to be updated in a popup notification"] = true
L["Show a list of all addons to be updated in a chat message"] = true
L["Show Minimap icon"] = true
L["Data addon is missing"] = true
