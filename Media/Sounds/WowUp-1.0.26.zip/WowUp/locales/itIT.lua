-- itIT localization
local L = LibStub("AceLocale-3.0"):NewLocale("WOWUP", "itIT")
if not L then return end

L["Notification"] = "Notifica"
L["You have %d addon to be updated"] = "Hai %d addon da aggiornare"
L["You have %d addons to be updated"] = "Hai %d addons da aggiornare"
L["All addons are up-to-date"] = "Tutti gli addons sono aggiornati"
L["Show a popup with a notification after loading when updates are available"] = "Mostra un popup di notifica quando sono disponibili degli aggiornamenti (dopo il Login)"
L["Show a chat message indicating whether or not updates are available"] = "Mostra un messaggio in chat se sono disponibili o meno degli aggiornamenti (dopo il Login)"
L["Click to open settings"] = "Click per aprire le impostazioni"
L["Show a list of all addons to be updated in a popup notification"] = "Mostra una lista di tutti gli addons da aggiornare in un popup di notifica"
L["Show a list of all addons to be updated in a chat message"] = "Mostra una lista di tutti gli addons da aggiornare in un messaggio in chat"
L["Show Minimap icon"] = "Mostra icona sulla minimappa"
L["Data addon is missing"] = "Dati dell'addon mancanti"
